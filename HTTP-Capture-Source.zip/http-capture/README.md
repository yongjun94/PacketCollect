# HTTP Capture — 개발 중인 Windows MVP

HTTP/HTTPS 수집 → 로컬 SQLite/Body 파일 → Dart SAZ/HAR Export. Flutter UI와 mitmproxy 엔진을 분리했습니다.

**Windows 제품 완료 상태가 아닙니다.** Linux에서 공통 모듈과 실제 프록시를 검증했습니다. Windows 빌드/실행, 인증서 저장소, 프록시 복원, Fiddler Classic Import, Chrome DevTools Import는 아직 검증하지 않았습니다. 보안·라이선스 배포 검토도 남아 있습니다. 최종 runtime 감사에서 Brotli 1.2.0 관련 advisory가 남아 있어 회사 배포 전 해결/검토가 필요합니다.

## Windows 실행판 진행 상태

Windows 빌드 자동화와 패키징 사전 점검을 추가했습니다. `.github/workflows/windows-build.yml`은 Windows 서버에서 release build → 테스트 → frozen engine smoke → ZIP 생성을 수행하도록 작성했습니다. **아직 원격 Windows workflow는 실행하지 않았고 EXE도 생성되지 않았습니다.** 자세한 절차와 이번 변경은 `docs/windows_build.md`를 참고하세요.

## Windows 개발 실행

빌드 개발자에게만 Flutter 3.35.5 / Dart 3.9.2, Python 3.12.x, Visual Studio의 Desktop development with C++ 및 Windows SDK가 필요합니다.

```powershell
.\scripts\dev_windows.ps1
```

앱에서 Start → Settings → fingerprint 확인 → 명시적으로 CA 설치 → 사용할 클라이언트의 HTTP/HTTPS 프록시를 `127.0.0.1:8877`로 설정합니다. Windows 현재 사용자 WinINet 프록시 설정 버튼도 제공합니다. PAC/회사 관리 설정은 변경하지 말고 승인된 수동 설정을 사용하세요. Stop 후 SAZ/HAR를 내보냅니다. 기존 파일을 덮어쓰지 않습니다.

## Windows 배포용 빌드

```powershell
.\scripts\build_windows.ps1
```

대상 OS에서 빌드하면 `dist/HTTP-Capture-Windows/HTTP-Capture.exe`, `proxy/` (Python 포함), `resources/`, `licenses/` 구성을 생성하도록 구현했습니다. 현재 환경에서는 이 Windows 빌드를 실행하지 못했습니다. 최종 사용자는 Python/Flutter를 설치하지 않는 구성이지만, 실제 패키지 실행 검증이 필요합니다. 코드 서명/설치 프로그램은 아직 없습니다.

## 파일 안내

- `docs/test_report.md`: 실제 검증 결과와 미완료 기준
- `docs/architecture.md`: 책임 분리 및 모바일 확장 경계
- `docs/development.md`: 재현 방법
- `docs/saz_format.md`, `docs/session_model.md`: 데이터 표현과 한계
- `docs/security.md`, `licenses/REVIEW_REQUIRED.md`: 배포 전 검토 사항
- `artifacts/loopback.saz`, `artifacts/loopback.har`: 실제 로컬 프록시 통합 테스트로 만든 합성 데이터 샘플. 실사용 고객 트래픽/개인키는 포함하지 않습니다.

Remote capture, macOS OS 연동, Android/iOS standalone은 구현되지 않았습니다. WebSocket 프레임과 HTTP/3는 지원하지 않습니다.
