"""Current-user WinINet only. Compare-before-restore journal, never WinHTTP."""
import ctypes
import json
import os
from pathlib import Path
import subprocess

KEY = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
NAMES = ("ProxyEnable", "ProxyServer", "ProxyOverride")


class WindowsProxy:
    def __init__(self, root: Path):
        self.journal = root / "proxy-journal.json"

    def _require(self):
        if os.name != 'nt':
            raise RuntimeError('System proxy adapter is implemented for Windows only')

    def read(self):
        self._require()
        import winreg
        values = {}
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY) as key:
            for name in (*NAMES, 'AutoConfigURL'):
                try:
                    value, kind = winreg.QueryValueEx(key, name)
                    values[name] = [value, kind]
                except FileNotFoundError:
                    values[name] = None
        return values

    def write(self, values):
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY, 0, winreg.KEY_SET_VALUE) as key:
            for name in NAMES:
                val = values[name]
                if val is None:
                    try:
                        winreg.DeleteValue(key, name)
                    except FileNotFoundError:
                        pass
                else:
                    winreg.SetValueEx(key, name, 0, val[1], val[0])
        from ctypes import wintypes
        wininet = ctypes.WinDLL('wininet', use_last_error=True)
        notify = wininet.InternetSetOptionW
        notify.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPVOID, wintypes.DWORD]
        notify.restype = wintypes.BOOL
        for option in (39, 37):
            if not notify(None, option, None, 0):
                raise ctypes.WinError(ctypes.get_last_error())

    def enable(self, port):
        self._require()
        import winreg
        if self.journal.exists():
            raise RuntimeError('Unresolved proxy journal. Recover before starting.')
        before = self.read()
        # PAC/WPAD are not overridden silently. WinInet UI includes auto-detect bits.
        if before.get('AutoConfigURL'):
            raise RuntimeError('PAC proxy detected. Use manual per-app proxy configuration.')
        installed = dict(before, ProxyEnable=[1, winreg.REG_DWORD],
                         ProxyServer=[f'127.0.0.1:{port}', winreg.REG_SZ],
                         ProxyOverride=['<-loopback>', winreg.REG_SZ])
        with open(self.journal, 'x') as f:
            json.dump({'before': before, 'installed': installed}, f)
            f.flush()
            os.fsync(f.fileno())
        try:
            self.write(installed)
        except Exception:
            self.restore()
            raise

    def restore(self):
        self._require()
        if not self.journal.exists():
            return 'No recovery required'
        state = json.loads(self.journal.read_text())
        current = self.read()
        # Accept a partly applied tuple, but refuse another actor's values.
        if any(current[n] not in (state['before'][n], state['installed'][n]) for n in NAMES):
            raise RuntimeError('Proxy changed externally. Journal kept; manual review required.')
        self.write(state['before'])
        self.journal.unlink()
        return 'Proxy restored'


def certificate_action(cert_path, action):
    if os.name != 'nt':
        raise RuntimeError('Certificate trust adapter is implemented for Windows only')
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes
    cert = x509.load_pem_x509_certificate(Path(cert_path).read_bytes())
    thumb = cert.fingerprint(hashes.SHA1()).hex().upper()
    fingerprint = cert.fingerprint(hashes.SHA256()).hex().upper()
    # Do not interpolate user paths into PowerShell. Read the argument via stdin.
    script = r"""
$j = [Console]::In.ReadToEnd() | ConvertFrom-Json
$p = 'Cert:\CurrentUser\Root\' + $j.thumb
$c = Get-Item -LiteralPath $p -ErrorAction SilentlyContinue
if ($c) {
 $sha = [System.Security.Cryptography.SHA256]::Create()
 $fp = [BitConverter]::ToString($sha.ComputeHash($c.RawData)).Replace('-','')
 if ($fp -ne $j.fingerprint) { throw 'Fingerprint mismatch' }
}
if ($j.action -eq 'install') { Import-Certificate -FilePath $j.path -CertStoreLocation Cert:\CurrentUser\Root | Out-Null }
if ($j.action -eq 'remove' -and $c) { Remove-Item -LiteralPath $p }
[bool](Test-Path -LiteralPath $p) | ConvertTo-Json -Compress
"""
    result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command',
                             "$ErrorActionPreference='Stop';" + script], input=json.dumps({
                                 'thumb': thumb, 'fingerprint': fingerprint,
                                 'action': action, 'path': str(Path(cert_path).resolve())}),
                            text=True, capture_output=True, check=True, timeout=20)
    return {'fingerprint': fingerprint, 'trusted': json.loads(result.stdout.strip())}
